/****************************************************************************
** Meta object code from reading C++ file 'rsscontroller.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "webui/api/rsscontroller.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rsscontroller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_RSSController_t {
    QByteArrayData data[14];
    char stringdata0[207];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RSSController_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RSSController_t qt_meta_stringdata_RSSController = {
    {
QT_MOC_LITERAL(0, 0, 13), // "RSSController"
QT_MOC_LITERAL(1, 14, 15), // "addFolderAction"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 13), // "addFeedAction"
QT_MOC_LITERAL(4, 45, 16), // "removeItemAction"
QT_MOC_LITERAL(5, 62, 14), // "moveItemAction"
QT_MOC_LITERAL(6, 77, 11), // "itemsAction"
QT_MOC_LITERAL(7, 89, 16), // "markAsReadAction"
QT_MOC_LITERAL(8, 106, 17), // "refreshItemAction"
QT_MOC_LITERAL(9, 124, 13), // "setRuleAction"
QT_MOC_LITERAL(10, 138, 16), // "renameRuleAction"
QT_MOC_LITERAL(11, 155, 16), // "removeRuleAction"
QT_MOC_LITERAL(12, 172, 11), // "rulesAction"
QT_MOC_LITERAL(13, 184, 22) // "matchingArticlesAction"

    },
    "RSSController\0addFolderAction\0\0"
    "addFeedAction\0removeItemAction\0"
    "moveItemAction\0itemsAction\0markAsReadAction\0"
    "refreshItemAction\0setRuleAction\0"
    "renameRuleAction\0removeRuleAction\0"
    "rulesAction\0matchingArticlesAction"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RSSController[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x08 /* Private */,
       3,    0,   75,    2, 0x08 /* Private */,
       4,    0,   76,    2, 0x08 /* Private */,
       5,    0,   77,    2, 0x08 /* Private */,
       6,    0,   78,    2, 0x08 /* Private */,
       7,    0,   79,    2, 0x08 /* Private */,
       8,    0,   80,    2, 0x08 /* Private */,
       9,    0,   81,    2, 0x08 /* Private */,
      10,    0,   82,    2, 0x08 /* Private */,
      11,    0,   83,    2, 0x08 /* Private */,
      12,    0,   84,    2, 0x08 /* Private */,
      13,    0,   85,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void RSSController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        RSSController *_t = static_cast<RSSController *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->addFolderAction(); break;
        case 1: _t->addFeedAction(); break;
        case 2: _t->removeItemAction(); break;
        case 3: _t->moveItemAction(); break;
        case 4: _t->itemsAction(); break;
        case 5: _t->markAsReadAction(); break;
        case 6: _t->refreshItemAction(); break;
        case 7: _t->setRuleAction(); break;
        case 8: _t->renameRuleAction(); break;
        case 9: _t->removeRuleAction(); break;
        case 10: _t->rulesAction(); break;
        case 11: _t->matchingArticlesAction(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject RSSController::staticMetaObject = {
    { &APIController::staticMetaObject, qt_meta_stringdata_RSSController.data,
      qt_meta_data_RSSController,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *RSSController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RSSController::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RSSController.stringdata0))
        return static_cast<void*>(this);
    return APIController::qt_metacast(_clname);
}

int RSSController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = APIController::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
